import { defineCollection, reference, z } from 'astro:content';
import { glob } from 'astro/loaders';

// =============================================================================
// 共通スキーマ部品
// =============================================================================

// すべての記事に共通するメタデータ
const baseSchema = z.object({
  title: z.string(),
  description: z.string().min(120).max(160), // meta description用、SEO最適長
  publishDate: z.coerce.date(),
  updateDate: z.coerce.date().optional(),
  heroImage: z.string(), // /images/places/sakurajima-hero.jpg のような形式
  heroImageAlt: z.string(),
  draft: z.boolean().default(false),
});

// 多くの記事で使う「ベストシーズン」
const seasonSchema = z.enum(['spring', 'summer', 'autumn', 'winter', 'year-round']);

// =============================================================================
// /places/ collection - 観光地記事
// =============================================================================
const places = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/places' }),
  schema: baseSchema.extend({
    // 地理情報(構造化データ用)
    location: z.object({
      lat: z.number(),
      lng: z.number(),
      address: z.string(), // 英語住所
      googleMapsUrl: z.string().url(),
    }),
    // 訪問情報
    visitInfo: z.object({
      bestSeason: z.array(seasonSchema),
      durationMinutes: z.number(), // 滞在目安(分)
      admissionFee: z.string().optional(), // "Free" or "¥1,000"
      openingHours: z.string().optional(),
    }),
    // エリア分類(将来のフィルタリング用)
    area: z.enum([
      'kagoshima-city',
      'satsuma-peninsula',
      'osumi-peninsula',
      'kirishima',
      'northern-kagoshima',
      'islands',
    ]),
    // 関連記事(slugで参照、型安全)
    relatedPlaces: z.array(reference('places')).optional(),
    relatedFood: z.array(reference('food')).optional(),
    accessFrom: z.array(reference('getting-around')).optional(),
  }),
});

// =============================================================================
// /food/ collection - 食記事
// =============================================================================
const food = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/food' }),
  schema: baseSchema.extend({
    // 料理 or 飲み物 or 食材の分類
    foodType: z.enum(['dish', 'drink', 'ingredient', 'sweet']),
    // 価格帯(レストラン目安)
    priceRange: z.enum(['budget', 'moderate', 'expensive']).optional(),
    // 焼酎・黒豚で重要:発祥地や産地
    origin: z.string().optional(),
    // 関連記事
    relatedFood: z.array(reference('food')).optional(),
    relatedPlaces: z.array(reference('places')).optional(),
  }),
});

// =============================================================================
// /onsen/ collection - 温泉記事
// =============================================================================
const onsen = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/onsen' }),
  schema: baseSchema.extend({
    location: z.object({
      lat: z.number(),
      lng: z.number(),
      address: z.string(),
    }),
    onsenInfo: z.object({
      springType: z.string(), // "Sulfur" "Carbonate" など
      temperature: z.number().optional(), // 摂氏
      hasOutdoorBath: z.boolean(),
      hasMixedGender: z.boolean(),
      tattooFriendly: z.boolean(), // 欧米客に重要
    }),
    relatedPlaces: z.array(reference('places')).optional(),
  }),
});

// =============================================================================
// /itineraries/ collection - モデルコース
// =============================================================================
const itineraries = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/itineraries' }),
  schema: baseSchema.extend({
    // 日数
    durationDays: z.number().int().min(1).max(14),
    // 推奨対象
    audience: z.enum([
      'first-timer',
      'repeat-visitor',
      'foodie',
      'nature-lover',
      'history-buff',
    ]),
    // 訪問する場所(slug参照)
    visitedPlaces: z.array(reference('places')),
    // 想定季節
    bestSeason: z.array(seasonSchema),
    // 出発地(あれば)
    startsFrom: reference('getting-there').optional(),
  }),
});

// =============================================================================
// /getting-there/ collection - 鹿児島への到達
// =============================================================================
const gettingThere = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/getting-there' }),
  schema: baseSchema.extend({
    // 出発地
    fromCity: z.string(), // "Tokyo" "Fukuoka" など
    // 移動手段(複数可)
    transportModes: z.array(
      z.enum(['shinkansen', 'plane', 'highway-bus', 'ferry', 'rental-car'])
    ),
    // 所要時間と費用の目安
    duration: z.string(), // "1h 20min" のような表記
    estimatedCost: z.string(), // "¥10,000 - ¥15,000"
    // JR Pass使用可否(欧米客に最重要)
    jrPassEligible: z.boolean(),
  }),
});

// =============================================================================
// /getting-around/ collection - 域内移動
// =============================================================================
const gettingAround = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/getting-around' }),
  schema: baseSchema.extend({
    // 移動手段の種類
    transportType: z.enum([
      'tram',
      'bus',
      'ferry',
      'train',
      'rental-car',
      'taxi',
      'walking',
    ]),
    // 利用エリア
    coverageArea: z.array(
      z.enum([
        'kagoshima-city',
        'sakurajima',
        'ibusuki',
        'kirishima',
        'islands',
        'prefecture-wide',
      ])
    ),
    // ICカード対応
    icCardAccepted: z.boolean().optional(),
  }),
});

// =============================================================================
// エクスポート
// =============================================================================
export const collections = {
  places,
  food,
  onsen,
  itineraries,
  'getting-there': gettingThere,
  'getting-around': gettingAround,
};
