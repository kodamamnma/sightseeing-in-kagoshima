---
title: "Sakurajima: Visiting Japan's Most Active Volcano"
description: "Sakurajima is an active volcano just across the bay from Kagoshima city. Learn how to get there, what to see, and what to expect from this iconic destination."
publishDate: 2026-05-01
heroImage: "/images/places/sakurajima-hero.jpg"
heroImageAlt: "View of Sakurajima volcano with smoke rising from the crater, taken from Kagoshima city across the bay"
draft: true

location:
  lat: 31.5853
  lng: 130.6577
  address: "Sakurajima, Kagoshima, Kagoshima Prefecture, Japan"
  googleMapsUrl: "https://www.google.com/maps/place/Sakurajima/"

visitInfo:
  bestSeason:
    - spring
    - autumn
  durationMinutes: 240
  admissionFee: "Free (volcano viewing); ¥390 ferry fare each way"
  openingHours: "Ferry runs 24 hours, every 15 minutes during the day"

area: "kagoshima-city"

relatedPlaces:
  - sengan-en
  - ibusuki

relatedFood:
  - kurobuta

accessFrom:
  - sakurajima-ferry
---

## What is Sakurajima?

Sakurajima is one of Japan's most active volcanoes, sitting in Kinko Bay just four kilometers from central Kagoshima. The volcano erupts hundreds of times each year, releasing small puffs of ash that residents have grown accustomed to.

(本文がここに続く...)
