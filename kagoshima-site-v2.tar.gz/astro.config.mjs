import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import tailwind from '@astrojs/tailwind';

export default defineConfig({
  // 本番環境のURL(サイトマップ生成、canonical URL、OGPに使用)
  // ドメイン取得後に正式なURLに変更する
  site: 'https://kagoshima-guide.example.com',

  // URLの末尾スラッシュを統一(SEO重要)
  // 'always' = /places/sakurajima/ (推奨、ディレクトリ構造を反映)
  trailingSlash: 'always',

  // ビルド時のHTMLフォーマット
  build: {
    format: 'directory', // /places/sakurajima/index.html を生成
    inlineStylesheets: 'auto', // 小さいCSSはインライン化(LCP改善)
  },

  // 画像最適化設定
  image: {
    // ローカル画像のドメイン(Cloudflareなどで配信する場合)
    domains: [],
  },

  // Astroインテグレーション
  integrations: [
    // sitemap.xml の自動生成
    sitemap({
      // 各ページの優先度を設定
      customPages: [],
      // 階層構造を反映した優先度
      serialize(item) {
        // トップページ
        if (item.url === 'https://kagoshima-guide.example.com/') {
          item.priority = 1.0;
          item.changefreq = 'weekly';
        }
        // Tier 2 ハブ(/places/, /food/ など)
        else if (item.url.match(/\/(places|food|onsen|itineraries|getting-there|getting-around)\/$/)) {
          item.priority = 0.8;
          item.changefreq = 'weekly';
        }
        // Tier 3 個別記事
        else {
          item.priority = 0.6;
          item.changefreq = 'monthly';
        }
        return item;
      },
    }),
    // Tailwind CSS
    tailwind({
      // ベーススタイルは独自定義したいので無効化
      applyBaseStyles: false,
    }),
  ],

  // Markdownの設定
  markdown: {
    shikiConfig: {
      // コードブロックのテーマ(技術解説記事を書くなら)
      theme: 'github-light',
    },
  },

  // 出力モード
  output: 'static', // 完全静的サイト(Cloudflare Pagesに最適)
});
