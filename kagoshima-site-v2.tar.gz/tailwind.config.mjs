/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      // 後で鹿児島ブランドカラーをここに定義する
      // 桜島の火山灰グレーや、薩摩切子の藍色など
      colors: {
        // 仮置き
        'sakurajima-ash': '#5a5654',
        'satsuma-indigo': '#1f3a5f',
      },
      fontFamily: {
        // 英語サイトなのでSerif系を見出しに使う想定
        serif: ['"Noto Serif"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      // 読みやすい本文幅(英語観光記事の標準)
      maxWidth: {
        article: '720px',
      },
    },
  },
  plugins: [],
};
